Contributions

The following sections of code were developed by the following team members.
1. Chris Major: K-nearest Neighbor (classification, regression), dited Nearest Neighbor, Condensed Nearest Neighbor
2. Farshina Nazrul-Shimim: Edited Nearest Neighbor, Condensed Nearest Neighbor
3. Tysen Radovich: K-Means, K-Medoids
4. Allen Simpson: K-Means, Loss Functions, Distance functions, K-Medoids
